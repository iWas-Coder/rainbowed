# Rainbowed (by iWas <3)

A tiny module to simply import colors in Python's stdout.
